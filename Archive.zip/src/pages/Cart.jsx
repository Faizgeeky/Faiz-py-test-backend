import { useState } from 'react'


// import { useDispatch, } from "react-redux";
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart, updateCartQuantity, addToCart, calculateTotal } from '../redux/cartSlice';
import { addFreeItem , removeFreeItem } from '../redux/freeSlice';
import offersData from '../data/Offers.json'; 
// import { addFreeItem, removeFreeItem } from '../redux/freeSlice';
const sampleProduct = {
    id: 431,
    type: "fruit",
    name: "Bananas",
    description: "Organic bananas",
    rating: 3.5,
    img: "https://py-shopping-cart.s3.eu-west-2.amazonaws.com/bananas.jpeg",
    price: "£2",
    available: 36
};
export default function Cart() {
    const [open, setOpen] = useState(true)
    const cart = useSelector((state) => state.cart);
    const dispatch = useDispatch();
    // const freeItems = useSelector(state => state.cart.freeItems);
    // const cartItems = useSelector(state => state.cart.cartItems);
    const cartTotal = useSelector(state => state.cart.cartTotal);
    const freeItems = useSelector(state => state.cart.freeItems) || []; // Use an empty array as default
    const cartItems = useSelector(state => state.cart.cartItems) || []; // Use an empty array as default


    const handleRemoveFromCart = (productId) => {
        dispatch(removeFromCart(productId));
    };

    const handleQuantityChange = (productId, quantity) => {
        dispatch(updateCartQuantity({ id: productId, quantity }));
    };

    const checkOffers = ()=>{
        offersData.map(offerItem => {
            console.log("Offer item:", offerItem);

            const matchingCartItem = cartItems.find(cartItem => cartItem.id === offerItem.id);

            if (matchingCartItem && matchingCartItem.quantity >= offerItem.total_buy) {
                console.log("Matching cart item:", matchingCartItem);

                // Check if free item already exists for this offer
                // if (freeItems?.length > 0) {

                    //check if fr
                // const existingFreeItem = freeItems.find(
                //     freeItem => freeItem.id === offerItem.offer_product_id
                // );

                // if (!existingFreeItem) {
                //     // Find the free item product in the cart
                    // const freeItemToAdd = cartItems.find(
                    //     cartItem => cartItem.id === offerItem.offer_product_id
                    // );

                //     if (freeItemToAdd) {
                //         dispatch(addFreeItem(freeItemToAdd)); // Dispatch action to add free item
                //     } else {
                //         console.error("Error: Free item product not found in cart", offerItem.offer_product_id);
                //     }
                // } else {
                //     console.log("Free item already exists for this offer:", offerItem.id);
                // }

               

                // } else {
                //     console.log("else part?")
                //     const freeItemToAdd = cartItems.find(
                //         cartItem => cartItem.id === offerItem.offer_product_id
                //     );

                //     if (freeItemToAdd) {

                //         dispatch(addFreeItem(freeItemToAdd)); // Dispatch action to add free item
                //     } else {
                //         console.error("Error: Free item product found in cart", offerItem.offer_product_id);

                //     }
                // }
            }
        })
    }

    useEffect(() => {
        dispatch(calculateTotal()); // Calculate total on every cart change
        console.log(freeItems)
        checkOffers();

    }, [cartItems, addFreeItem, handleQuantityChange, updateCartQuantity, freeItems]);

   
        
       
        // console.log("---", matchingItem);

    

    return (
           <>
            {cartItems.length === 0 ? (
                <div>
                <h1 className='text-2xl font-bold mx-20 '>Checkout</h1>
                    <h3 className='text-center mx-20 my-20'>Shopping cart is empty</h3>
                    <Link to="/">
                        <p type="button"
                            className="font-medium text-center text-indigo-600 hover:text-indigo-500">
                            Continue Shopping
                            <span aria-hidden="true"> &rarr;</span>
                        </p>
                    </Link>
                </div>
            ) : (
                <div>
                <div className="cart-container">
                   
                            <h1 className='text-2xl font-bold mx-20 '>Checkout</h1>

              
                </div>
                    <div className='px-48'>
                            <div className="mt-8">
                                <div className="flow-root">
                                    <ul role="list" className="-my-6 divide-y divide-gray-200">
                                        {cartItems.map((product) => (
                                            <li key={product.id} className="flex py-6">
                                                <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                                                    <img
                                                        src={product.img}
                                                        alt={product.name}
                                                        className="h-full w-full object-cover object-center"
                                                    />
                                                </div>

                                                <div className="ml-4 flex flex-1 flex-col">
                                                    <div>
                                                        <div className="flex justify-between text-base font-medium text-gray-900">
                                                            <h3>
                                                                <a href={product.img}>{product.name}</a>
                                                            </h3>
                                                            <p className="ml-4">{product.price}</p>
                                                        </div>
                                                        <p className="mt-1 text-sm text-gray-500">{product.color}</p>
                                                    </div>
                                                    <div className="flex flex-1 items-end justify-between text-sm">
                                                        <div className="flex items-center"> {/* Center the quantity controls */}
                                                            <button
                                                                type="button"
                                                                className="font-medium text-indigo-600 hover:text-indigo-500 mr-2"
                                                                onClick={() => handleQuantityChange(product.id, product.quantity -1 )}
                                                            >
                                                                -
                                                            </button>
                                                            <p className="text-gray-500">Qty {product.quantity}</p>
                                                            <button
                                                                type="button"
                                                                className="font-medium text-indigo-600 hover:text-indigo-500 ml-2"
                                                                onClick={() => handleQuantityChange(product.id, product.quantity + 1)}
                                                            >
                                                                +
                                                            </button>
                                                        </div>
                                                        <div className="flex"> {/* Move "Remove" button to the right */}
                                                            <button
                                                                type="button"
                                                                className="font-medium text-indigo-600 hover:text-indigo-500"
                                                                onClick={() => handleRemoveFromCart(product.id)}
                                                            >
                                                                Remove
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>

                            <div className="border-t border-gray-200 px-4 py-6 sm:px-6">
                                <div className="flex justify-between text-base font-medium text-gray-900">
                                    <p>Subtotal</p>
                                    <p>£{cartTotal.toFixed(2) }</p>
                                </div>
                                <p className="mt-0.5 text-sm text-gray-500">Shipping and taxes calculated at checkout.</p>
                                <div className="mt-6">
                                    <a
                                        href="#"
                                        className="flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-indigo-700"
                                    >
                                        Checkout
                                    </a>
                                </div>
                                <div className="mt-6 flex justify-center text-center text-sm text-gray-500">
                                    <p>
                                        or{' '}
                                        <Link to="/">
                                        <p
                                            type="button"
                                            className="font-medium text-indigo-600 hover:text-indigo-500"
                                            onClick={() => setOpen(false)}
                                        >
                                            Continue Shopping
                                            <span aria-hidden="true"> &rarr;</span>
                                        </p>
                                        </Link>
                                    </p>
                                </div>
                            </div>
                    
                    
                    </div>
                    </div>
            )}
            {freeItems}
        
           </>
                    
             
         
    )
}
// src/components/Cart.js


// const Cart = () => {
//     const cartItems = useSelector(state => state.cart.cartItems);
//     const dispatch = useDispatch();

    // const handleRemoveFromCart = (productId) => {
    //     dispatch(removeFromCart(productId));
    // };

    // const handleQuantityChange = (productId, quantity) => {
    //     dispatch(updateCartQuantity({ id: productId, quantity }));
    // };

//     return (
//         <div>
//             <h2>Shopping Cart</h2>
            // {cartItems.length === 0 ? (
            //     <p>Cart is empty</p>
            // ) : (
//                 <ul>
//                     {cartItems.map(item => (
//                         <li key={item.id}>
//                             <img src={item.img} alt={item.name} width="50" />
//                             <h3>{item.name}</h3>
//                             <p>{item.description}</p>
//                             <p>Price: {item.price}</p>
//                             <p>Rating: {item.rating}</p>
//                             <input
//                                 type="number"
//                                 value={item.quantity}
//                                 onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value))}
//                             />
//                             <button onClick={() => handleRemoveFromCart(item.id)}>Remove</button>
//                         </li>
//                     ))}
//                 </ul>
//             )}
//         </div>
//     );
// };

// export default Cart;
